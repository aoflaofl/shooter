package com.example.shooter.input;

public class Binding {
    public String action;
    public InputType type;
    public int button;
    public int axisX;
    public int axisY;
    public float deadzone = 0.20f;
}
