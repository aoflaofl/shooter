package com.example.shooter.state;

public class InventoryState implements GameState {
    @Override public void update(double dt) {}
    @Override public void render() {}
    @Override public void dispose() {}
}
