package com.example.shooter.state;

import com.example.shooter.render.Renderer2D;
import com.example.shooter.input.Gamepad;
import static org.lwjgl.glfw.GLFW.*;

public class MenuState implements GameState {
    private final long window;
    private final StateMachine sm;
    private final Renderer2D r = new Renderer2D();

    public MenuState(long window, StateMachine sm) {
        this.window = window; this.sm = sm;
    }

    @Override public void update(double dt) {
        Gamepad.poll();
        if (Gamepad.actionJustPressed("UI_ACCEPT")) {
            sm.change(new GameplayState(window, sm));
        }
        if (Gamepad.actionJustPressed("UI_BACK")) {
            glfwSetWindowShouldClose(window, true);
        }
    }

    @Override public void render() {
        r.begin();
        r.text(40, 60, "Shooter Demo");
        r.text(40, 120, "Press A to Start");
        r.end();
    }

    @Override public void dispose() { r.dispose(); }
}
