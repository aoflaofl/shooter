package com.example.shooter.io;

import java.util.ArrayList;
import java.util.List;

public class SaveData {
    public int level = 1;
    public int score = 0;
    public List<String> inventory = new ArrayList<>();
}
