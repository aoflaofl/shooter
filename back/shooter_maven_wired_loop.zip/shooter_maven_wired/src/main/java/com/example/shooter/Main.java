package com.example.shooter;

public class Main {
    public static void main(String[] args) {
        new Game(1280, 720, "Shooter Demo").run();
    }
}
