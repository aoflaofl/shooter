package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class Guardian {
    public enum Phase { BUILDING, AWAKENING, ACTIVE, DYING }
    private Phase phase = Phase.BUILDING;
    private float completion = 0.0f;
    private int coreHp = 6;
    private Vec2f pos = new Vec2f(300, 200);
    public float buildProgressPerCell = 0.05f;
    public float awakenTime = 2.0f;
    public float chaseSpeed = 220f;
    private float awakenTimer = 0f;
    private float dashCooldown = 0f;
    private boolean destroyed = false;

    public Guardian(int coreHp) { this.coreHp = coreHp; }
    public Phase phase() { return phase; }
    public float completion() { return completion; }
    public boolean isDestroyed() { return destroyed; }
    public Vec2f position() { return pos; }

    public void queueComponents(int cellAmount) {
        if (phase != Phase.BUILDING) return;
        completion += cellAmount * buildProgressPerCell;
        if (completion >= 1f) { completion = 1f; phase = Phase.AWAKENING; awakenTimer = awakenTime; }
    }

    public void update(double dt, Vec2f playerPos) {
        switch (phase) {
            case BUILDING -> {}
            case AWAKENING -> { awakenTimer -= dt; if (awakenTimer <= 0) phase = Phase.ACTIVE; }
            case ACTIVE -> {
                Vec2f dir = new Vec2f(playerPos.x() - pos.x(), playerPos.y() - pos.y()).norm();
                pos = pos.add(dir.mul((float)(chaseSpeed * dt)));
                if (dashCooldown > 0) dashCooldown -= dt;
            }
            case DYING -> { destroyed = true; }
        }
    }
    public void applySpecialHit(int damage) { if (phase == Phase.ACTIVE && (coreHp -= damage) <= 0) phase = Phase.DYING; }
}
