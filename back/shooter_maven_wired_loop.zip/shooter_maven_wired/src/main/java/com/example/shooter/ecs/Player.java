package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;
import com.example.shooter.render.Renderer2D;
import com.example.shooter.render.Texture;

public class Player {
    private Vec2f pos = new Vec2f(640, 360);
    private float speed = 350f;
    private final Texture tex = Texture.load("assets/textures/player.png");
    private final float w = 48, h = 48;

    public void move(Vec2f axis, double dt) {
        Vec2f v = axis.norm().mul(speed * (float)dt);
        pos = pos.add(v);
    }

    public void draw(Renderer2D r) { r.sprite(tex, pos.x()-w/2, pos.y()-h/2, w, h); }
    public float getX() { return pos.x(); }
    public float getY() { return pos.y(); }
}
