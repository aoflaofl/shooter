package com.example.shooter.input;

public enum InputType { BUTTON, AXIS1, AXIS2 }
