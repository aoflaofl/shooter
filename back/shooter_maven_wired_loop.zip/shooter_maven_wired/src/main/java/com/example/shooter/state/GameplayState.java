package com.example.shooter.state;

import com.example.shooter.audio.Sound;
import com.example.shooter.ecs.Player;
import com.example.shooter.ecs.Guardian;
import com.example.shooter.input.Gamepad;
import com.example.shooter.render.Renderer2D;
import com.example.shooter.math.Vec2f;
import com.example.shooter.systems.SpawnController;

public class GameplayState implements GameState {
    private final Renderer2D r = new Renderer2D();
    private final Player player = new Player();
    private final Sound sShoot = Sound.load("/assets/sounds/shoot.wav");

    // Wired systems/entities
    private final SpawnController spawner = new SpawnController();
    private final Guardian guardian = new Guardian(6);

    public GameplayState(long window, StateMachine sm) {}

    @Override public void update(double dt) {
        Gamepad.poll();
        var move = Gamepad.axis("MOVE");
        player.move(move, dt);

        if (Gamepad.actionPressed("FIRE")) {
            if (!sShoot.isPlaying()) sShoot.play();
        }

        spawner.update(dt);
        guardian.update(dt, new Vec2f(player.getX(), player.getY()));
    }

    @Override public void render() {
        r.begin();
        player.draw(r);
        var gp = guardian.position();
        r.rect(gp.x()-32, gp.y()-32, 64, 64);
        r.text(20, 20, "Guardian: " + (int)(guardian.completion()*100) + "%");
        r.end();
    }

    @Override public void dispose() { r.dispose(); sShoot.dispose(); }
}
