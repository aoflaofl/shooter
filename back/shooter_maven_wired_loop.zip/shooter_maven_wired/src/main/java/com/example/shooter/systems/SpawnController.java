package com.example.shooter.systems;

import java.util.Random;

public class SpawnController {
    public int builderCap = 4, defenderCap = 3, debrisBudget = 30;
    public double builderRate = 0.4, defenderRate = 0.25;
    private double nextBuilder = 0, nextDefender = 0;
    private final Random rng = new Random();
    public void update(double dt) {
        nextBuilder -= dt; nextDefender -= dt;
        if (nextBuilder <= 0) { nextBuilder = jitter(builderRate); /* TODO: spawn builder */ }
        if (nextDefender <= 0) { nextDefender = jitter(defenderRate); /* TODO: spawn defender */ }
        // TODO: maintain debrisBudget
    }
    private double jitter(double rate) { double mean = rate<=0?1.0:(1.0/rate); return 0.5*mean + rng.nextDouble()*mean; }
}
