package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class Builder {
    public enum State { SEEK_DEBRIS, MINE, CARRY_TO_SITE, DEPOSIT, EVADE }
    public State state = State.SEEK_DEBRIS;

    public Vec2f pos = new Vec2f(100, 100);
    public float speed = 140f;
    public int carried = 0;
    public int carryCapacity = 5;
    public int hp = 3;
    public Vec2f buildSite = new Vec2f(640, 360);

    public void update(double dt) {
        switch (state) {
            case SEEK_DEBRIS -> {}
            case MINE -> {}
            case CARRY_TO_SITE -> {}
            case DEPOSIT -> { state = State.SEEK_DEBRIS; }
            case EVADE -> {}
        }
    }
}
