package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class Debris {
    public Vec2f pos;
    public Vec2f vel;
    public int cells;
    public int hp;

    public Debris(Vec2f pos, Vec2f vel, int cells, int hp) {
        this.pos = pos; this.vel = vel; this.cells = cells; this.hp = hp;
    }

    public void update(double dt) {
        pos = pos.add(vel.mul((float)dt));
    }
}
