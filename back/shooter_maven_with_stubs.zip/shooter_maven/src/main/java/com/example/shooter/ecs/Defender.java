package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class Defender {
    public enum State { PATROL, CHASE, STRAFE, RETREAT }
    public State state = State.PATROL;

    public Vec2f pos = new Vec2f(200, 200);
    public float patrolSpeed = 120f;
    public float chaseSpeed = 200f;
    public int hp = 4;

    public void update(double dt, Vec2f playerPos) {
        float dx = playerPos.x() - pos.x();
        float dy = playerPos.y() - pos.y();
        float dist2 = dx*dx + dy*dy;
        if (hp <= 1) state = State.RETREAT;
        else if (dist2 < 200*200) state = State.CHASE;
        else state = State.PATROL;

        switch (state) {
            case PATROL -> {}
            case CHASE -> {
                Vec2f dir = new Vec2f(dx, dy).norm();
                pos = pos.add(dir.mul((float)(chaseSpeed * dt)));
            }
            case STRAFE -> {}
            case RETREAT -> {}
        }
    }
}
