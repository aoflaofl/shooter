package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class PowerCell {
    public Vec2f pos;
    public Vec2f vel = new Vec2f(0,0);

    public PowerCell(Vec2f pos) { this.pos = pos; }

    public void update(double dt, Vec2f attractor) {
        Vec2f dir = new Vec2f(attractor.x() - pos.x(), attractor.y() - pos.y()).norm();
        vel = vel.add(dir.mul(50f * (float)dt));
        pos = pos.add(vel.mul((float)dt));
    }
}
