package com.example.shooter.ecs;

import com.example.shooter.math.Vec2f;

public class Projectile {
    public Vec2f pos;
    public Vec2f vel;
    public int damage;
    public boolean alive = true;

    public Projectile(Vec2f pos, Vec2f vel, int damage) {
        this.pos = pos; this.vel = vel; this.damage = damage;
    }

    public void update(double dt) {
        pos = pos.add(vel.mul((float)dt));
    }
}
