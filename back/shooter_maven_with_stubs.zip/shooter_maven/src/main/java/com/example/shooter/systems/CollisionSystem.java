package com.example.shooter.systems;

public class CollisionSystem {
    public void resolve() {
        // TODO: implement AABB checks and apply damage / pickups
    }
}
